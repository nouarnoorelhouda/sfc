=======================
networking-sfc policies
=======================

The following is an overview of all available policies in networking-sfc.
For a sample configuration file, refer to :doc:`/configuration/policy-sample`.

.. show-policy::
      :config-file: etc/oslo-policy-generator/policy.conf
